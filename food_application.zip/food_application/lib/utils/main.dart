import 'package:carousel_slider/carousel_options.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'card.dart';
import 'listview.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(fontFamily: 'Your Font Family'),
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(kToolbarHeight),
          child: Padding(
            padding: const EdgeInsets.only(top: 20.0),
            child: AppBar(
              leading: IconButton(
                icon: const Icon(Icons.arrow_back_ios_new),
                onPressed: () {},
              ),
              title: const Text(
                "My Food App",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
              ),
              centerTitle: true,
            ),
          ),
        ),
        body: content(),
        bottomNavigationBar: NavigationBar(
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.home),
              label: "Home",
            ),
            NavigationDestination(
              icon: Icon(Icons.location_on_outlined),
              label: "Discovery",
            ),
            NavigationDestination(
              icon: Icon(Icons.bookmark_border),
              label: "Bookmark",
            ),
            NavigationDestination(
              icon: Icon(Icons.emoji_events),
              label: "Top Foodie",
            ),
            NavigationDestination(
              icon: Icon(Icons.face),
              label: "Profile",
            )
          ],
        ),
      ),
    );
  }

  Widget content() {
    return Padding(
      padding: const EdgeInsets.only(top: 35),
      child: Column(
        children: [
          Container(
            child: CarouselSlider(
                items: [1, 2, 3, 4, 5].map((i) {
                  return Container(
                      width: 500,
                      margin: EdgeInsets.symmetric(horizontal: 20.0),
                      decoration: BoxDecoration(
                          color: Colors.cyan,
                          borderRadius: BorderRadius.circular(10)),
                      child: Align(
                        alignment: Alignment.bottomLeft,
                        child: Padding(
                          padding: EdgeInsets.only(left: 20.0, bottom: 10.0),
                          child: Text(
                            "Slide $i",
                            style: TextStyle(fontSize: 30),
                          ),
                        ),
                      ));
                }).toList(),
                options: CarouselOptions(height: 200)),
          ),
          Container(
            width: double.infinity,
            child: listView_popular(),
          ),
        ],
      ),
    );
  }
}
