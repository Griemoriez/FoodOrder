import 'package:flutter/material.dart';

class NavigationMenu extends StatelessWidget {
  const NavigationMenu({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: NavigationBar(
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home), label: "Home", 
          ),
          NavigationDestination(
            icon: Icon(Icons.location_on_outlined), label: "Discovery", 
          ),
          NavigationDestination(
            icon: Icon(Icons.bookmark_border), label: "Bookmark",
          ),
          NavigationDestination(
            icon: Icon(Icons.emoji_events), label: "Top Foodie",
          ),
          NavigationDestination(
            icon: Icon(Icons.face), label: "Profile",
          )
        ],
      ),
    );
  }
}
